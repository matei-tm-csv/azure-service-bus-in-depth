﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SimpleBrokeredMessaging.Receiver
{
    class ReceiverConsole
    {
        //ToDo: Enter a valid Serivce Bus connection string
        static string ConnectionString = "";
        static string QueuePath = "demoqueue";

        

        static void Main(string[] args)
        {
            // Create a queue client
            


            // Create a message handler to receive messages
            



            Console.WriteLine("Press enter to exit.");
            Console.ReadLine();

            // Close the client
            
            

        }




    }
}
