﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkingWithMessages.Config
{
    public class Settings
    {
        //ToDo: Enter a valid Service Bus connection string
        public static string ConnectionString = "";
        public static string QueueName = "workingwithmessages";




       
    }
}
