﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkingWithMessages.MessageEntities
{
    public class PizzaOrder
    {
        public string CustomerName { get; set; }
        public string Type { get; set; }
        public String Size { get; set; }
    }
}
