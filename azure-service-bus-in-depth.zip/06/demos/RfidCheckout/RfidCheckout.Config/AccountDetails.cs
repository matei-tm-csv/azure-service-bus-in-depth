﻿
namespace RfidCheckout.Config
{
    public class AccountDetails
    {
        //ToDo: Enter a valid Serivce Bus connection string
        public static string ConnectionString = "";
        public static string QueueName = "rfidcheckout";
    }
}


